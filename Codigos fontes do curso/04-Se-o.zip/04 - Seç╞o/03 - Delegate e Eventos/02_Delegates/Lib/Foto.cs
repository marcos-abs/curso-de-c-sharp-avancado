﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_Delegates.Lib
{
    public class Foto
    {
        public string Nome { get; set; }
        public int TamanhoX { get; set; }
        public int TamanhoY { get; set; }
    }
}
