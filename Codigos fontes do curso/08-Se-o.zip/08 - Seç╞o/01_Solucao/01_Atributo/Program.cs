﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Atributo
{
    [MeuAtributo("Atributo Classe", Descricao = "Descrição do Atributo")]
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
