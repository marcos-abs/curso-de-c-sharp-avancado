﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_LINQ_OBJ
{
    class Usuario
    {
        public string Nome { get; set; }
        public string Email { get; set; }
    }
}
