﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Generics.Modelo
{
    public class Casa
    {
        public string Cidade;
        public string Endereco;
    }
}
